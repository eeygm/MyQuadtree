# MyQuadtree
<a href="https://travis-ci.org/eeygm/MyQuadtree">
<img src="https://travis-ci.org/eeygm/MyQuadtree.svg?branch=master"></img>
</a>
