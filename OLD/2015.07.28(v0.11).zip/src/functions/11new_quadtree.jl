function new_quadtree(a::Int64, b::Int64, c::Int64, d::Int64)
  return Quadtree(Rectangle(a,b,c,d))
end
